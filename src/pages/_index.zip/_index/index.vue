<template>
  <div class="page">
    <div class="index">
      <div class="container total" :style="'background: url('+totalbg+') center no-repeat;background-size:100%'">
        <div class="deviceTotal">
          <h3 class="fn">设备总数</h3>
          <p>1500</p>
        </div>
        <ul class="deviceState">
          <li>
            <h3 class="fn">运行设备数量</h3>
            <p>750</p>
          </li>
          <li>
            <h3 class="fn">停机设备数量</h3>
            <p>50</p>
          </li>
          <li>
            <h3 class="fn">监控设备数量</h3>
            <p>3000</p>
          </li>
        </ul>
      </div>
      <div v-if="Category.length" class="Category">
        <div v-if="item.icon" v-for="(item,i) in category" :key="i" class="container bgw">
          <h3 class="title">{{item.name}}</h3>
          <ul style="margin:.10rem 0 .15rem 0">
            <li v-if="itemI.Icon" v-for="(itemI,j) in item.list" :key="j">
              <a :class="'align'+itemI.order%3" :href="filter(itemI.Url)">
                <img class="icon" :src="itemI.Icon">
                <p>{{itemI.Name}}</p>
                <em v-if="tip[itemI.id]&&tip[itemI.id].num" class="tip">{{tip[itemI.id].num}}</em>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>

  </div>

</template>

<script>
  import {
    cookiesValue
  } from '../../utils/cookies';

  export default {
    name: 'Index',
    //inject: ["reload", "Toast"],
    data() {
      return {
        Category: [],
        totalbg: require("@/images/home_bg_img.png"),
        category: {
          repair: {
            name: "报修", icon: undefined, list: [
              { id: "2d1608bb-4efd-4433-954b-9db96cb469ab", name: "设备报修" },
              { id: "db8d5e53-4b60-44fb-82b6-26da8f41a64d", name: "我的报修" }]
          },
          job: {
            name: "工单", icon: undefined, list: [
              { id: "23d2d273-ab80-4cca-984a-fd4bf0bf62c0", name: "工单派单" },
              { id: "44d98cbd-bdfe-4bc3-94bb-7af6af36e1c2", name: "我的工单" }]
          },
          device: {
            name: "设备", icon: undefined, list: [
              { id: "848a8b0a-a747-4675-881c-9861b27d9f36", name: "设备台账" }]
          },
          other: {
            name: "其他", icon: undefined, list: [
              { id: "ad56febe-089d-4c39-9e12-aa48a61bf912", name: "备件查询" },
              { id: "4c94f3d9-be86-473d-a0cf-3487a25514e5", name: "消息中心" },
              { id: "abbf5176-0e85-4316-84d2-ec3c2927ed22", name: "工作日历" }]
          },
        },
        tip: {
          "db8d5e53-4b60-44fb-82b6-26da8f41a64d": { name: "我的报修", num: 0 },
          "23d2d273-ab80-4cca-984a-fd4bf0bf62c0": { name: "工单派单", num: 0 },
          "44d98cbd-bdfe-4bc3-94bb-7af6af36e1c2": { name: "我的工单", num: 0 }
        }
      }
    },
    created() {
      var that = this;
      window.addEventListener("scroll", function (e) {
        if (((e.target.documentElement.scrollTop || e.target.body.scrollTop) + e.target.documentElement.clientHeight) > (e.target.body.clientHeight - 1)) {
        }
      });
    },
    computed: {
    },
    mounted() {
      this.loading();
      //this.loadTip();
    },
    methods: {
      filter(url) {
        return (location.hostname === "localhost" || location.hostname === "127.0.0.1") || location.hostname === "10.18.201.211" ? url.substr(28) : url;
      },
      loading() {
        this.$ReqIndex.moduleList({ userId: cookiesValue("ZT_DevicePlatForm_UserId") }).then((res) => {
          this.Category = res.data.list;
          for (var i in this.category) {
            var order = 0, item = this.category[i];
            for (var j in item.list) {
              for (var k = 0; k < res.data.list.length; k++) {
                if (item.list[j].id === res.data.list[k].Id) {
                  this.category[i].icon = true;
                  item.list[j].order = order;
                  order += 1;
                  for (var m in res.data.list[k]) {
                    item.list[j][m] = res.data.list[k][m];
                  }
                }
              }
            }
          }
          console.log(this.category)
        });
      },

      loadTip() {
        this.$ReqRepair.getStatus({ status: 1 }).then((status) => {
          this.$ReqRepair.getList({ pageIndex: 1, pageSize: 100, createrId: cookiesValue("ZT_DevicePlatForm_UserId"), statusId: status.data.list[3].Id }).then((res) => {
            this.tip["db8d5e53-4b60-44fb-82b6-26da8f41a64d"].num = res.data.list.length;
          });
        });
        this.$ReqJob.getStatus({ status: 1 }).then((status) => {
          this.$ReqDispatch.getList({ pageIndex: 1, pageSize: 100, createrId: cookiesValue("ZT_DevicePlatForm_UserId"), flag: 1, statusId: status.data.list[0].Id }).then((res) => {
            this.tip["23d2d273-ab80-4cca-984a-fd4bf0bf62c0"].num = res.data.list.length;
          });
          this.$ReqJob.getList({ pageIndex: 1, pageSize: 100, createrId: cookiesValue("ZT_DevicePlatForm_UserId"), flag: 0, statusId: status.data.list[1].Id }).then((res) => {
            this.tip["44d98cbd-bdfe-4bc3-94bb-7af6af36e1c2"].num = res.data.list.length;
          });

        });

      }
    },
  }
</script>

<style>
  @import "../../css/index.css";
</style>