
import main from '@/pages/main'
import Index from './index'

main.init(Index);