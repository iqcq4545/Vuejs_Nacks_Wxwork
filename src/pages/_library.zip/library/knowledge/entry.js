
import main from '@/pages/main'
import Knowledge from './knowledge'

main.init(Knowledge)