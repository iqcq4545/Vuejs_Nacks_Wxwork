
import main from '@/pages/main'
import Document from './document'

main.init(Document)