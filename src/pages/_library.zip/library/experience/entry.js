
import main from '@/pages/main'
import Experience from './experience'

main.init(Experience)