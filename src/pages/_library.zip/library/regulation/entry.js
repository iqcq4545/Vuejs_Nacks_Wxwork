
import main from '@/pages/main'
import Regulation from './regulation'

main.init(Regulation)